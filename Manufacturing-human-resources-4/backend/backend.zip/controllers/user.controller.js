import User from '../models/User.js'; 
import bcryptjs from 'bcryptjs'

export const signup = async (req, res) => {
    try {
    const { fullName, username, email, phone, address, password } = req.body;
    if(!fullName||!email||!username|| !phone|| !address|| !password)
        {return res.status(400).json({message: " All feilds are required"})};
    
    if(password.length < 6){ return res.status(400).json({ message: "password must be at least 6 character long"})};
  
    const existingUser = await User.findOne({ email });
    if( existingUser) {
      return res.status(400).json({message : "user already exists"})
    }
    // const newUser = new User({ fullName, email, phone, address, password });
    const salt =await bcryptjs.genSalt(10);
    const hashedPassword = await bcryptjs.hash(password,salt);
    const user = new User({fullName, username, email, phone, address, password: hashedPassword})
    await user.save()
    res.status(201).json({message: "user registered successfully"})
    
      // await newUser.save();
      // res.status(201).json({ message: 'User created successfully!' });
    } catch (error) {
      res.status(400).json({ error: 'Error creating user' });
    }
  }


  // nagpunta muna ako sa folder ng manufacuring un un kaya cd .\Manufacturing-human-resources-4\