import express from 'express';
// import User from '../models/User.js'; 
// import bcrypt from 'bycrptjs'
import { signup } from '../controllers/user.controller.js'

const router = express.Router();

router.post('/signup',signup);

export default router;